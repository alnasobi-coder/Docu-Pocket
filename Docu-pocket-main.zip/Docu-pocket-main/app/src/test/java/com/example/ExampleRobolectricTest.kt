package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.repository.VaultRepository
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Docu Pocket", appName)
    }

    @Test
    fun `vault repository creates independent hidden directory and handles files`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repository = VaultRepository(context)

        // Hidden directory verification
        assertTrue(repository.vaultRoot.name.startsWith("."))
        assertTrue(repository.vaultRoot.exists())

        // Create folder with auto-delete
        val folderCreated = repository.createFolder(
            parentRelativePath = "",
            folderName = "WorkNotes",
            autoDeleteEnabled = true,
            durationHours = 24L
        )
        assertTrue(folderCreated)

        // Create text file
        val textFile = repository.writeTextFile("WorkNotes", "Meeting.txt", "Important discussion notes")
        assertTrue(textFile.exists())

        // Save description
        repository.saveDescription("WorkNotes/Meeting.txt", "Meeting notes from client sync")

        // Read content
        val content = repository.readTextFile("WorkNotes/Meeting.txt")
        assertEquals("Important discussion notes", content)
    }
}
