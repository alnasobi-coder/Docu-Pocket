package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.local.dao.FileMetadataDao
import com.example.data.local.dao.FolderConfigDao
import com.example.data.local.entity.FileMetadataEntity
import com.example.data.local.entity.FolderConfigEntity

@Database(
    entities = [FileMetadataEntity::class, FolderConfigEntity::class],
    version = 1,
    exportSchema = false
)
abstract class VaultDatabase : RoomDatabase() {
    abstract fun fileMetadataDao(): FileMetadataDao
    abstract fun folderConfigDao(): FolderConfigDao

    companion object {
        @Volatile
        private var INSTANCE: VaultDatabase? = null

        fun getInstance(context: Context): VaultDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    VaultDatabase::class.java,
                    "file_vault.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
