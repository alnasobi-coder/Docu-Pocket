package com.example.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.FileMetadataEntity
import com.example.data.local.entity.FolderConfigEntity
import com.example.data.model.FileCategory
import com.example.data.model.SortOption
import com.example.data.model.StorageAnalytics
import com.example.data.model.ThemeMode
import com.example.data.model.VaultItem
import com.example.data.repository.VaultRepository
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

data class Breadcrumb(
    val title: String,
    val path: String
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    val repository = VaultRepository(application)

    private val _currentPath = MutableStateFlow("")
    val currentPath: StateFlow<String> = _currentPath.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _isGlobalSearch = MutableStateFlow(false)
    val isGlobalSearch: StateFlow<String> get() = _searchQuery // or bool

    private val _sortOption = MutableStateFlow(SortOption.NAME_ASC)
    val sortOption: StateFlow<SortOption> = _sortOption.asStateFlow()

    private val _isGridView = MutableStateFlow(false)
    val isGridView: StateFlow<Boolean> = _isGridView.asStateFlow()

    private val _themeMode = MutableStateFlow(ThemeMode.SYSTEM)
    val themeMode: StateFlow<ThemeMode> = _themeMode.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _storageAnalytics = MutableStateFlow<StorageAnalytics?>(null)
    val storageAnalytics: StateFlow<StorageAnalytics?> = _storageAnalytics.asStateFlow()

    private val _toastEvent = MutableSharedFlow<String>()
    val toastEvent: SharedFlow<String> = _toastEvent.asSharedFlow()

    // Dialog & Sheet States
    val showNewFolderDialog = MutableStateFlow(false)
    val showImageToPdfDialog = MutableStateFlow(false)
    val showStorageAnalyticsDialog = MutableStateFlow(false)
    val showNewTextFileDialog = MutableStateFlow(false)

    val activeDescriptionItem = MutableStateFlow<VaultItem?>(null)
    val activeRenameItem = MutableStateFlow<VaultItem?>(null)
    val activeDeleteItem = MutableStateFlow<VaultItem?>(null)
    val activeMoveItem = MutableStateFlow<VaultItem?>(null)
    val activeFolderConfigItem = MutableStateFlow<VaultItem?>(null)
    val activeViewerItem = MutableStateFlow<VaultItem?>(null)

    // Incoming Share sheet files
    val incomingSharedUris = MutableStateFlow<List<Uri>>(emptyList())
    val showIncomingShareDialog = MutableStateFlow(false)

    // Available subfolders for picker (e.g. For Move or Incoming Share)
    val allSubfolders = MutableStateFlow<List<String>>(listOf(""))

    // Raw files state trigger
    private val refreshTrigger = MutableStateFlow(0L)

    val allMetadata = repository.observeAllMetadata().stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    val allFolderConfigs = repository.observeAllFolderConfigs().stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    // Current displayed items
    private val _vaultItems = MutableStateFlow<List<VaultItem>>(emptyList())
    val vaultItems: StateFlow<List<VaultItem>> = _vaultItems.asStateFlow()

    init {
        // Initial auto-delete check on launch
        viewModelScope.launch {
            val cleaned = repository.checkAndExecuteAutoDelete()
            if (cleaned > 0) {
                _toastEvent.emit("Auto-cleanup removed $cleaned expired folder(s)")
            }
            refreshItems()
            refreshStorageAnalytics()
        }

        // Reactively reload items when path, query, sort, metadata, or configs change
        val filterFlow = combine(
            _currentPath,
            _searchQuery,
            _sortOption,
            refreshTrigger
        ) { path, query, sort, trigger ->
            Triple(path, query, sort) to trigger
        }

        viewModelScope.launch {
            combine(
                filterFlow,
                allMetadata,
                allFolderConfigs
            ) { (filter, _), metas, configs ->
                val (path, query, sort) = filter
                loadAndProcessItems(path, query, sort, metas, configs)
            }.collect { items ->
                _vaultItems.value = items
            }
        }

        viewModelScope.launch {
            combine(allFolderConfigs, refreshTrigger) { configs, _ ->
                updateSubfoldersList(configs)
            }.collect { folders ->
                allSubfolders.value = folders
            }
        }
    }

    private suspend fun loadAndProcessItems(
        path: String,
        query: String,
        sort: SortOption,
        metas: List<FileMetadataEntity>,
        configs: List<FolderConfigEntity>
    ): List<VaultItem> {
        val rawList = if (query.isNotBlank()) {
            repository.listAllFilesRecursively(metas, configs)
        } else {
            repository.listItems(path, metas, configs)
        }

        val filtered = if (query.isBlank()) rawList else {
            rawList.filter { item ->
                item.name.contains(query, ignoreCase = true) ||
                        (item.description?.contains(query, ignoreCase = true) == true)
            }
        }

        return sortItems(filtered, sort)
    }

    private fun sortItems(items: List<VaultItem>, sort: SortOption): List<VaultItem> {
        // Folders always pinned to top
        val folders = items.filter { it.isDirectory }
        val files = items.filter { !it.isDirectory }

        fun compare(list: List<VaultItem>): List<VaultItem> {
            return when (sort) {
                SortOption.NAME_ASC -> list.sortedBy { it.name.lowercase() }
                SortOption.NAME_DESC -> list.sortedByDescending { it.name.lowercase() }
                SortOption.DATE_DESC -> list.sortedByDescending { it.lastModified }
                SortOption.DATE_ASC -> list.sortedBy { it.lastModified }
                SortOption.SIZE_DESC -> list.sortedByDescending { it.sizeBytes }
                SortOption.SIZE_ASC -> list.sortedBy { it.sizeBytes }
                SortOption.TYPE -> list.sortedWith(compareBy({ it.category.name }, { it.name.lowercase() }))
            }
        }

        return compare(folders) + compare(files)
    }

    private suspend fun updateSubfoldersList(configs: List<FolderConfigEntity>): List<String> {
        val list = mutableListOf("") // root
        fun walk(dir: File) {
            val children = dir.listFiles() ?: return
            for (c in children) {
                if (c.isDirectory) {
                    val rel = repository.getRelativePath(c)
                    list.add(rel)
                    walk(c)
                }
            }
        }
        walk(repository.vaultRoot)
        return list.sorted()
    }

    fun refreshItems() {
        refreshTrigger.value = System.currentTimeMillis()
    }

    fun navigateTo(folderRelativePath: String) {
        _searchQuery.value = ""
        _currentPath.value = folderRelativePath.trim().trimStart('/')
    }

    fun navigateUp(): Boolean {
        val current = _currentPath.value
        if (current.isEmpty()) return false
        val parent = if (current.contains('/')) current.substringBeforeLast('/') else ""
        navigateTo(parent)
        return true
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSortOption(option: SortOption) {
        _sortOption.value = option
    }

    fun toggleGridView() {
        _isGridView.value = !_isGridView.value
    }

    fun setThemeMode(mode: ThemeMode) {
        _themeMode.value = mode
    }

    val breadcrumbs: StateFlow<List<Breadcrumb>> = combine(_currentPath) { paths ->
        val current = paths[0]
        val list = mutableListOf(Breadcrumb("Vault", ""))
        if (current.isNotBlank()) {
            val segments = current.split('/')
            var cumulative = ""
            for (segment in segments) {
                if (segment.isNotBlank()) {
                    cumulative = if (cumulative.isEmpty()) segment else "$cumulative/$segment"
                    list.add(Breadcrumb(segment, cumulative))
                }
            }
        }
        list
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        listOf(Breadcrumb("Vault", ""))
    )

    fun createFolder(folderName: String, autoDeleteEnabled: Boolean, durationHours: Long) {
        viewModelScope.launch {
            _isLoading.value = true
            val success = repository.createFolder(
                parentRelativePath = _currentPath.value,
                folderName = folderName,
                autoDeleteEnabled = autoDeleteEnabled,
                durationHours = durationHours
            )
            _isLoading.value = false
            if (success) {
                _toastEvent.emit("Folder '$folderName' created")
                refreshItems()
            } else {
                _toastEvent.emit("Could not create folder. Name may already exist.")
            }
        }
    }

    fun updateFolderAutoDelete(folderRelativePath: String, enabled: Boolean, durationHours: Long) {
        viewModelScope.launch {
            repository.updateFolderAutoDelete(folderRelativePath, enabled, durationHours)
            _toastEvent.emit("Auto-delete settings updated")
            refreshItems()
        }
    }

    fun importFiles(uris: List<Uri>, targetFolder: String = _currentPath.value, description: String? = null) {
        viewModelScope.launch {
            _isLoading.value = true
            var count = 0
            for (uri in uris) {
                val file = repository.importFileFromUri(uri, targetFolder, description = description)
                if (file != null) count++
            }
            _isLoading.value = false
            _toastEvent.emit("Imported $count file(s) to vault")
            refreshItems()
            refreshStorageAnalytics()
        }
    }

    fun saveDescription(relativePath: String, description: String) {
        viewModelScope.launch {
            repository.saveDescription(relativePath, description)
            _toastEvent.emit("Description saved")
            refreshItems()
        }
    }

    fun renameItem(relativePath: String, newName: String) {
        viewModelScope.launch {
            val success = repository.renameItem(relativePath, newName)
            if (success) {
                _toastEvent.emit("Renamed successfully")
                refreshItems()
            } else {
                _toastEvent.emit("Rename failed. Name might already exist.")
            }
        }
    }

    fun deleteItem(relativePath: String) {
        viewModelScope.launch {
            val success = repository.deleteItem(relativePath)
            if (success) {
                _toastEvent.emit("Item deleted")
                refreshItems()
                refreshStorageAnalytics()
            } else {
                _toastEvent.emit("Delete failed")
            }
        }
    }

    fun moveItem(sourceRelativePath: String, destFolderRelativePath: String) {
        viewModelScope.launch {
            val success = repository.moveItem(sourceRelativePath, destFolderRelativePath)
            if (success) {
                _toastEvent.emit("Moved item successfully")
                refreshItems()
            } else {
                _toastEvent.emit("Failed to move item")
            }
        }
    }

    fun saveTextFile(parentRelativeFolder: String, fileName: String, content: String) {
        viewModelScope.launch {
            _isLoading.value = true
            repository.writeTextFile(parentRelativeFolder, fileName, content)
            _isLoading.value = false
            _toastEvent.emit("Saved '$fileName'")
            refreshItems()
            refreshStorageAnalytics()
        }
    }

    suspend fun readTextFile(relativePath: String): String {
        return repository.readTextFile(relativePath)
    }

    fun convertImagesToPdf(
        imageUris: List<Uri>,
        outputName: String,
        targetFolder: String = _currentPath.value,
        description: String? = null
    ) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val pdfFile = repository.convertImagesToPdf(
                    imageUris = imageUris,
                    outputName = outputName,
                    targetFolderRelative = targetFolder,
                    description = description
                )
                _toastEvent.emit("PDF '${pdfFile.name}' created in vault!")
                refreshItems()
                refreshStorageAnalytics()
            } catch (e: Exception) {
                e.printStackTrace()
                _toastEvent.emit("Failed to create PDF: ${e.localizedMessage}")
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun refreshStorageAnalytics() {
        viewModelScope.launch {
            _storageAnalytics.value = repository.getStorageAnalytics()
        }
    }

    fun runAutoDeleteCleanup() {
        viewModelScope.launch {
            _isLoading.value = true
            val count = repository.checkAndExecuteAutoDelete()
            _isLoading.value = false
            _toastEvent.emit("Cleaned up $count expired folder(s)")
            refreshItems()
            refreshStorageAnalytics()
        }
    }

    fun onIncomingSharesReceived(uris: List<Uri>) {
        if (uris.isNotEmpty()) {
            incomingSharedUris.value = uris
            showIncomingShareDialog.value = true
        }
    }

    fun saveIncomingSharedFiles(targetFolder: String, description: String?) {
        val uris = incomingSharedUris.value
        importFiles(uris, targetFolder, description)
        incomingSharedUris.value = emptyList()
        showIncomingShareDialog.value = false
    }
}
