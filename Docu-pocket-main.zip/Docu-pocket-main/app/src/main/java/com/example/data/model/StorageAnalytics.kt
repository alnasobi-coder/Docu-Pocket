package com.example.data.model

import java.util.Locale

data class CategoryUsage(
    val category: FileCategory,
    val totalBytes: Long,
    val fileCount: Int,
    val percentageOfVault: Float
) {
    val formattedBytes: String
        get() = formatBytes(totalBytes)
}

data class StorageAnalytics(
    val totalDeviceBytes: Long = 0L,
    val freeDeviceBytes: Long = 0L,
    val usedDeviceBytes: Long = 0L,
    val totalVaultBytes: Long = 0L,
    val totalVaultFiles: Int = 0,
    val totalVaultFolders: Int = 0,
    val categoryBreakdown: List<CategoryUsage> = emptyList(),
    val activeAutoDeleteFoldersCount: Int = 0
) {
    val deviceUsedRatio: Float
        get() = if (totalDeviceBytes > 0) (usedDeviceBytes.toFloat() / totalDeviceBytes.toFloat()).coerceIn(0f, 1f) else 0f

    val formattedDeviceTotal: String
        get() = formatBytes(totalDeviceBytes)

    val formattedDeviceUsed: String
        get() = formatBytes(usedDeviceBytes)

    val formattedDeviceFree: String
        get() = formatBytes(freeDeviceBytes)

    val formattedVaultTotal: String
        get() = formatBytes(totalVaultBytes)
}

fun formatBytes(bytes: Long): String {
    if (bytes <= 0) return "0 B"
    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt().coerceIn(0, units.size - 1)
    val value = bytes / Math.pow(1024.0, digitGroups.toDouble())
    return String.format(Locale.getDefault(), "%.1f %s", value, units[digitGroups])
}
