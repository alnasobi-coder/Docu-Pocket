package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoDelete
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.NoteAdd
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SettingsBrightness
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material.icons.filled.ViewList
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.model.FileCategory
import com.example.data.model.SortOption
import com.example.data.model.ThemeMode
import com.example.data.model.VaultItem
import com.example.ui.MainViewModel
import com.example.ui.components.BreadcrumbsBar
import com.example.ui.components.DeleteConfirmDialog
import com.example.ui.components.DescriptionSheet
import com.example.ui.components.FileViewerDialog
import com.example.ui.components.FolderAutoDeleteDialog
import com.example.ui.components.ImageToPdfDialog
import com.example.ui.components.IncomingShareDialog
import com.example.ui.components.MoveItemDialog
import com.example.ui.components.NewFolderDialog
import com.example.ui.components.NewTextFileDialog
import com.example.ui.components.RenameDialog
import com.example.ui.components.StorageAnalyticsDialog
import com.example.ui.components.VaultItemGridCard
import com.example.ui.components.VaultItemListRow
import com.example.ui.components.VaultMenuAction
import com.example.ui.components.openFileWithSystem
import com.example.ui.components.shareFileWithSystem
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainVaultScreen(
    viewModel: MainViewModel
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val snackbarHostState = remember { SnackbarHostState() }

    val currentPath by viewModel.currentPath.collectAsStateWithLifecycle()
    val breadcrumbs by viewModel.breadcrumbs.collectAsStateWithLifecycle()
    val vaultItems by viewModel.vaultItems.collectAsStateWithLifecycle()
    val isGridView by viewModel.isGridView.collectAsStateWithLifecycle()
    val sortOption by viewModel.sortOption.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()
    val isLoading by viewModel.isLoading.collectAsStateWithLifecycle()
    val analytics by viewModel.storageAnalytics.collectAsStateWithLifecycle()

    val allSubfolders by viewModel.allSubfolders.collectAsStateWithLifecycle()

    // Dialog state collectors
    val showNewFolder by viewModel.showNewFolderDialog.collectAsStateWithLifecycle()
    val showImageToPdf by viewModel.showImageToPdfDialog.collectAsStateWithLifecycle()
    val showAnalytics by viewModel.showStorageAnalyticsDialog.collectAsStateWithLifecycle()
    val showNewTextFile by viewModel.showNewTextFileDialog.collectAsStateWithLifecycle()

    val activeDescriptionItem by viewModel.activeDescriptionItem.collectAsStateWithLifecycle()
    val activeRenameItem by viewModel.activeRenameItem.collectAsStateWithLifecycle()
    val activeDeleteItem by viewModel.activeDeleteItem.collectAsStateWithLifecycle()
    val activeMoveItem by viewModel.activeMoveItem.collectAsStateWithLifecycle()
    val activeFolderConfigItem by viewModel.activeFolderConfigItem.collectAsStateWithLifecycle()
    val activeViewerItem by viewModel.activeViewerItem.collectAsStateWithLifecycle()

    val incomingUris by viewModel.incomingSharedUris.collectAsStateWithLifecycle()
    val showIncomingShare by viewModel.showIncomingShareDialog.collectAsStateWithLifecycle()

    var isSearchActive by remember { mutableStateOf(false) }
    var sortMenuExpanded by remember { mutableStateOf(false) }
    var fabMenuExpanded by remember { mutableStateOf(false) }

    // Intercept back button to navigate up folders
    BackHandler(enabled = currentPath.isNotEmpty() || isSearchActive) {
        if (isSearchActive) {
            isSearchActive = false
            viewModel.setSearchQuery("")
        } else {
            viewModel.navigateUp()
        }
    }

    LaunchedEffect(Unit) {
        viewModel.toastEvent.collectLatest { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    // Dynamic Generic Document/File Picker Launcher for Drawer Quick Imports
    var pendingImportMimeTypes by remember { mutableStateOf(arrayOf("*/*")) }
    val genericFilePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) {
            viewModel.importFiles(uris)
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                modifier = Modifier
                    .width(310.dp)
                    .testTag("navigation_drawer")
            ) {
                // Drawer Header
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f))
                        .padding(20.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(
                            painter = painterResource(id = R.drawable.ic_docupocket_logo_1791004034177),
                            contentDescription = null,
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(12.dp))
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Docu Pocket",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Text(
                                text = "Independent Hidden Storage",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.8f)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Vault: ${analytics?.formattedVaultTotal ?: "..."}",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "${analytics?.totalVaultFiles ?: 0} files",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Section 1: Quick Import by Category
                Text(
                    text = "QUICK IMPORT BY CATEGORY",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                )

                NavigationDrawerItem(
                    icon = { Icon(Icons.Default.PictureAsPdf, contentDescription = null, tint = FileCategory.PDF.color) },
                    label = { Text("Import PDFs") },
                    selected = false,
                    onClick = {
                        scope.launch { drawerState.close() }
                        pendingImportMimeTypes = arrayOf("application/pdf")
                        genericFilePickerLauncher.launch(pendingImportMimeTypes)
                    },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )

                NavigationDrawerItem(
                    icon = { Icon(FileCategory.IMAGE.icon, contentDescription = null, tint = FileCategory.IMAGE.color) },
                    label = { Text("Import Images") },
                    selected = false,
                    onClick = {
                        scope.launch { drawerState.close() }
                        pendingImportMimeTypes = arrayOf("image/*")
                        genericFilePickerLauncher.launch(pendingImportMimeTypes)
                    },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )

                NavigationDrawerItem(
                    icon = { Icon(FileCategory.DOCUMENT.icon, contentDescription = null, tint = FileCategory.DOCUMENT.color) },
                    label = { Text("Import Documents") },
                    selected = false,
                    onClick = {
                        scope.launch { drawerState.close() }
                        pendingImportMimeTypes = arrayOf(
                            "application/pdf",
                            "application/msword",
                            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                            "application/vnd.ms-excel",
                            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                            "text/*"
                        )
                        genericFilePickerLauncher.launch(pendingImportMimeTypes)
                    },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )

                NavigationDrawerItem(
                    icon = { Icon(FileCategory.AUDIO.icon, contentDescription = null, tint = FileCategory.AUDIO.color) },
                    label = { Text("Import Audio") },
                    selected = false,
                    onClick = {
                        scope.launch { drawerState.close() }
                        pendingImportMimeTypes = arrayOf("audio/*")
                        genericFilePickerLauncher.launch(pendingImportMimeTypes)
                    },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )

                NavigationDrawerItem(
                    icon = { Icon(FileCategory.VIDEO.icon, contentDescription = null, tint = FileCategory.VIDEO.color) },
                    label = { Text("Import Videos") },
                    selected = false,
                    onClick = {
                        scope.launch { drawerState.close() }
                        pendingImportMimeTypes = arrayOf("video/*")
                        genericFilePickerLauncher.launch(pendingImportMimeTypes)
                    },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )

                NavigationDrawerItem(
                    icon = { Icon(Icons.Default.UploadFile, contentDescription = null) },
                    label = { Text("Import Any File (*/*)") },
                    selected = false,
                    onClick = {
                        scope.launch { drawerState.close() }
                        pendingImportMimeTypes = arrayOf("*/*")
                        genericFilePickerLauncher.launch(pendingImportMimeTypes)
                    },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )

                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp, horizontal = 16.dp))

                // Section 2: Vault Tools & Analytics
                Text(
                    text = "VAULT TOOLS",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                )

                NavigationDrawerItem(
                    icon = { Icon(Icons.Default.PictureAsPdf, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
                    label = { Text("Image to PDF Converter") },
                    selected = false,
                    onClick = {
                        scope.launch { drawerState.close() }
                        viewModel.showImageToPdfDialog.value = true
                    },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding).testTag("drawer_image_to_pdf_item")
                )

                NavigationDrawerItem(
                    icon = { Icon(Icons.Default.PieChart, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
                    label = { Text("Storage Analytics") },
                    selected = false,
                    onClick = {
                        scope.launch { drawerState.close() }
                        viewModel.refreshStorageAnalytics()
                        viewModel.showStorageAnalyticsDialog.value = true
                    },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding).testTag("drawer_storage_analytics_item")
                )

                NavigationDrawerItem(
                    icon = { Icon(Icons.Default.AutoDelete, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
                    label = { Text("Run Auto-Delete Cleanup") },
                    selected = false,
                    onClick = {
                        scope.launch { drawerState.close() }
                        viewModel.runAutoDeleteCleanup()
                    },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )

                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp, horizontal = 16.dp))

                // Section 3: Theme Support (Day / Night)
                Text(
                    text = "THEME MODE",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ThemeMode.entries.forEach { mode ->
                        val isSelected = themeMode == mode
                        Surface(
                            onClick = { viewModel.setThemeMode(mode) },
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                            contentColor = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = when (mode) {
                                            ThemeMode.SYSTEM -> Icons.Default.SettingsBrightness
                                            ThemeMode.LIGHT -> Icons.Default.LightMode
                                            ThemeMode.DARK -> Icons.Default.DarkMode
                                        },
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = when (mode) {
                                            ThemeMode.SYSTEM -> "Auto"
                                            ThemeMode.LIGHT -> "Light"
                                            ThemeMode.DARK -> "Dark"
                                        },
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    ) {
        Scaffold(
            topBar = {
                Column {
                    TopAppBar(
                        title = {
                            if (isSearchActive) {
                                OutlinedTextField(
                                    value = searchQuery,
                                    onValueChange = { viewModel.setSearchQuery(it) },
                                    placeholder = { Text("Search files or notes...") },
                                    singleLine = true,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("search_text_field"),
                                    trailingIcon = {
                                        if (searchQuery.isNotEmpty()) {
                                            IconButton(onClick = { viewModel.setSearchQuery("") }) {
                                                Icon(Icons.Default.Clear, contentDescription = "Clear")
                                            }
                                        }
                                    }
                                )
                            } else {
                                Column {
                                    Text(
                                        text = if (currentPath.isEmpty()) "Docu Pocket" else currentPath.substringAfterLast('/'),
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = if (currentPath.isEmpty()) "Hidden Device Storage" else currentPath,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        },
                        navigationIcon = {
                            if (isSearchActive) {
                                IconButton(onClick = {
                                    isSearchActive = false
                                    viewModel.setSearchQuery("")
                                }) {
                                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Exit search")
                                }
                            } else if (currentPath.isNotEmpty()) {
                                IconButton(onClick = { viewModel.navigateUp() }) {
                                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                                }
                            } else {
                                IconButton(onClick = { scope.launch { drawerState.open() } }) {
                                    Icon(Icons.Default.Menu, contentDescription = "Open Drawer")
                                }
                            }
                        },
                        actions = {
                            if (!isSearchActive) {
                                IconButton(
                                    onClick = { isSearchActive = true },
                                    modifier = Modifier.testTag("search_button")
                                ) {
                                    Icon(Icons.Default.Search, contentDescription = "Search")
                                }

                                IconButton(onClick = { viewModel.toggleGridView() }) {
                                    Icon(
                                        imageVector = if (isGridView) Icons.Default.ViewList else Icons.Default.GridView,
                                        contentDescription = "Toggle Grid/List View"
                                    )
                                }

                                Box {
                                    IconButton(onClick = { sortMenuExpanded = true }) {
                                        Icon(Icons.AutoMirrored.Filled.Sort, contentDescription = "Sort Options")
                                    }
                                    DropdownMenu(
                                        expanded = sortMenuExpanded,
                                        onDismissRequest = { sortMenuExpanded = false }
                                    ) {
                                        SortOption.entries.forEach { opt ->
                                            DropdownMenuItem(
                                                text = {
                                                    Text(
                                                        text = opt.displayName,
                                                        fontWeight = if (sortOption == opt) FontWeight.Bold else FontWeight.Normal,
                                                        color = if (sortOption == opt) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                                    )
                                                },
                                                onClick = {
                                                    viewModel.setSortOption(opt)
                                                    sortMenuExpanded = false
                                                }
                                            )
                                        }
                                    }
                                }

                                IconButton(
                                    onClick = {
                                        viewModel.refreshStorageAnalytics()
                                        viewModel.showStorageAnalyticsDialog.value = true
                                    }
                                ) {
                                    Icon(Icons.Default.PieChart, contentDescription = "Storage Analytics")
                                }
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        )
                    )

                    // Breadcrumbs Path Navigator
                    if (!isSearchActive && currentPath.isNotEmpty()) {
                        BreadcrumbsBar(
                            breadcrumbs = breadcrumbs,
                            onCrumbClick = { path -> viewModel.navigateTo(path) }
                        )
                    }
                }
            },
            snackbarHost = { SnackbarHost(snackbarHostState) },
            floatingActionButton = {
                Column(horizontalAlignment = Alignment.End) {
                    AnimatedVisibility(visible = fabMenuExpanded) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            horizontalAlignment = Alignment.End,
                            modifier = Modifier.padding(bottom = 12.dp)
                        ) {
                            // Convert Image to PDF
                            ExtendedFabPill(
                                icon = Icons.Default.PictureAsPdf,
                                label = "Image to PDF",
                                color = MaterialTheme.colorScheme.error,
                                onClick = {
                                    fabMenuExpanded = false
                                    viewModel.showImageToPdfDialog.value = true
                                }
                            )

                            // New Text Document
                            ExtendedFabPill(
                                icon = Icons.Default.NoteAdd,
                                label = "New Text Note",
                                color = MaterialTheme.colorScheme.secondary,
                                onClick = {
                                    fabMenuExpanded = false
                                    viewModel.showNewTextFileDialog.value = true
                                }
                            )

                            // Import Files
                            ExtendedFabPill(
                                icon = Icons.Default.UploadFile,
                                label = "Import Files",
                                color = MaterialTheme.colorScheme.primary,
                                onClick = {
                                    fabMenuExpanded = false
                                    genericFilePickerLauncher.launch(arrayOf("*/*"))
                                }
                            )

                            // New Folder
                            ExtendedFabPill(
                                icon = Icons.Default.CreateNewFolder,
                                label = "New Folder",
                                color = MaterialTheme.colorScheme.tertiary,
                                onClick = {
                                    fabMenuExpanded = false
                                    viewModel.showNewFolderDialog.value = true
                                }
                            )
                        }
                    }

                    FloatingActionButton(
                        onClick = { fabMenuExpanded = !fabMenuExpanded },
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.testTag("main_fab")
                    ) {
                        Icon(
                            imageVector = if (fabMenuExpanded) Icons.Default.Clear else Icons.Default.Add,
                            contentDescription = "Add or import"
                        )
                    }
                }
            }
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .background(MaterialTheme.colorScheme.background)
            ) {
                if (isLoading) {
                    CircularProgressIndicator(
                        modifier = Modifier.align(Alignment.Center)
                    )
                } else if (vaultItems.isEmpty()) {
                    EmptyVaultState(
                        isSearching = searchQuery.isNotEmpty(),
                        onCreateFolder = { viewModel.showNewFolderDialog.value = true },
                        onImportFiles = { genericFilePickerLauncher.launch(arrayOf("*/*")) },
                        onImageToPdf = { viewModel.showImageToPdfDialog.value = true }
                    )
                } else {
                    if (isGridView) {
                        LazyVerticalGrid(
                            columns = GridCells.Adaptive(minSize = 140.dp),
                            contentPadding = PaddingValues(16.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(vaultItems, key = { it.relativePath }) { item ->
                                VaultItemGridCard(
                                    item = item,
                                    onClick = { handleItemClick(item, viewModel, context) },
                                    onMenuAction = { action -> handleMenuAction(action, viewModel, context) }
                                )
                            }
                        }
                    } else {
                        LazyColumn(
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(vaultItems, key = { it.relativePath }) { item ->
                                VaultItemListRow(
                                    item = item,
                                    onClick = { handleItemClick(item, viewModel, context) },
                                    onMenuAction = { action -> handleMenuAction(action, viewModel, context) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // ---------------- Dialogs & Sheets ---------------- //

    // 1. New Folder Dialog (with Auto-Delete toggle & duration selection)
    if (showNewFolder) {
        NewFolderDialog(
            onDismiss = { viewModel.showNewFolderDialog.value = false },
            onConfirm = { name, autoDelete, durationHours ->
                viewModel.createFolder(name, autoDelete, durationHours)
                viewModel.showNewFolderDialog.value = false
            }
        )
    }

    // 2. Folder Auto-Delete Settings for existing folder
    activeFolderConfigItem?.let { folderItem ->
        FolderAutoDeleteDialog(
            item = folderItem,
            onDismiss = { viewModel.activeFolderConfigItem.value = null },
            onSave = { enabled, durationHours ->
                viewModel.updateFolderAutoDelete(folderItem.relativePath, enabled, durationHours)
                viewModel.activeFolderConfigItem.value = null
            }
        )
    }

    // 3. Rename Dialog
    activeRenameItem?.let { item ->
        RenameDialog(
            currentName = item.name,
            onDismiss = { viewModel.activeRenameItem.value = null },
            onConfirm = { newName ->
                viewModel.renameItem(item.relativePath, newName)
                viewModel.activeRenameItem.value = null
            }
        )
    }

    // 4. Delete Confirm Dialog
    activeDeleteItem?.let { item ->
        DeleteConfirmDialog(
            item = item,
            onDismiss = { viewModel.activeDeleteItem.value = null },
            onConfirm = {
                viewModel.deleteItem(item.relativePath)
                viewModel.activeDeleteItem.value = null
            }
        )
    }

    // 5. Move Item Dialog
    activeMoveItem?.let { item ->
        MoveItemDialog(
            item = item,
            availableFolders = allSubfolders,
            onDismiss = { viewModel.activeMoveItem.value = null },
            onConfirmMove = { destFolder ->
                viewModel.moveItem(item.relativePath, destFolder)
                viewModel.activeMoveItem.value = null
            }
        )
    }

    // 6. Description Sheet (Viewing & editing note, highlighting the thumbnail dot indicator)
    activeDescriptionItem?.let { item ->
        DescriptionSheet(
            item = item,
            onDismiss = { viewModel.activeDescriptionItem.value = null },
            onSaveDescription = { description ->
                viewModel.saveDescription(item.relativePath, description)
                viewModel.activeDescriptionItem.value = null
            }
        )
    }

    // 7. File Viewer & Editor Dialog
    activeViewerItem?.let { item ->
        FileViewerDialog(
            item = item,
            onDismiss = { viewModel.activeViewerItem.value = null },
            onSaveTextContent = { content ->
                viewModel.saveTextFile(
                    parentRelativeFolder = item.relativePath.substringBeforeLast('/', ""),
                    fileName = item.name,
                    content = content
                )
            },
            onLoadTextContent = {
                viewModel.readTextFile(item.relativePath)
            }
        )
    }

    // 8. Image to PDF Converter Dialog
    if (showImageToPdf) {
        ImageToPdfDialog(
            availableFolders = allSubfolders,
            currentFolder = currentPath,
            onDismiss = { viewModel.showImageToPdfDialog.value = false },
            onGeneratePdf = { uris, outputName, targetFolder, description ->
                viewModel.convertImagesToPdf(uris, outputName, targetFolder, description)
            }
        )
    }

    // 9. Storage Analytics Dialog
    if (showAnalytics) {
        StorageAnalyticsDialog(
            analytics = analytics,
            onDismiss = { viewModel.showStorageAnalyticsDialog.value = false },
            onRunCleanup = { viewModel.runAutoDeleteCleanup() },
            onRefresh = { viewModel.refreshStorageAnalytics() }
        )
    }

    // 10. New Text Document Dialog
    if (showNewTextFile) {
        NewTextFileDialog(
            onDismiss = { viewModel.showNewTextFileDialog.value = false },
            onConfirm = { fileName, content ->
                viewModel.saveTextFile(currentPath, fileName, content)
                viewModel.showNewTextFileDialog.value = false
            }
        )
    }

    // 11. Incoming Shared Files Dialog (from WhatsApp or other apps)
    if (showIncomingShare && incomingUris.isNotEmpty()) {
        IncomingShareDialog(
            uris = incomingUris,
            availableFolders = allSubfolders,
            onDismiss = { viewModel.showIncomingShareDialog.value = false },
            onSaveToFolder = { targetFolder, description ->
                viewModel.saveIncomingSharedFiles(targetFolder, description)
            },
            onCreateFolderPrompt = { viewModel.showNewFolderDialog.value = true }
        )
    }
}

private fun handleItemClick(item: VaultItem, viewModel: MainViewModel, context: android.content.Context) {
    if (item.isDirectory) {
        viewModel.navigateTo(item.relativePath)
    } else {
        if (item.category == FileCategory.IMAGE || item.category == FileCategory.CODE_TEXT) {
            viewModel.activeViewerItem.value = item
        } else {
            openFileWithSystem(context, item)
        }
    }
}

private fun handleMenuAction(action: VaultMenuAction, viewModel: MainViewModel, context: android.content.Context) {
    when (action) {
        is VaultMenuAction.Open -> {
            if (action.item.isDirectory) {
                viewModel.navigateTo(action.item.relativePath)
            } else {
                viewModel.activeViewerItem.value = action.item
            }
        }
        is VaultMenuAction.EditDescription -> {
            viewModel.activeDescriptionItem.value = action.item
        }
        is VaultMenuAction.EditTextContent -> {
            viewModel.activeViewerItem.value = action.item
        }
        is VaultMenuAction.ConfigureAutoDelete -> {
            viewModel.activeFolderConfigItem.value = action.item
        }
        is VaultMenuAction.Rename -> {
            viewModel.activeRenameItem.value = action.item
        }
        is VaultMenuAction.Move -> {
            viewModel.activeMoveItem.value = action.item
        }
        is VaultMenuAction.Share -> {
            shareFileWithSystem(context, action.item)
        }
        is VaultMenuAction.Delete -> {
            viewModel.activeDeleteItem.value = action.item
        }
    }
}

@Composable
fun ExtendedFabPill(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    color: androidx.compose.ui.graphics.Color,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(24.dp),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 3.dp
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
fun EmptyVaultState(
    isSearching: Boolean,
    onCreateFolder: () -> Unit,
    onImportFiles: () -> Unit,
    onImageToPdf: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Surface(
            shape = CircleShape,
            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
            modifier = Modifier.size(88.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = if (isSearching) Icons.Default.Search else Icons.Default.Folder,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(42.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        Text(
            text = if (isSearching) "No matching files found" else "Vault is Empty",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = if (isSearching) "Try a different search term or check spelling."
            else "Only files you import or create are kept in this secure hidden vault.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )

        if (!isSearching) {
            Spacer(modifier = Modifier.height(24.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = onImportFiles) {
                    Icon(Icons.Default.UploadFile, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Import Files")
                }

                Button(onClick = onCreateFolder) {
                    Icon(Icons.Default.CreateNewFolder, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("New Folder")
                }
            }
        }
    }
}
