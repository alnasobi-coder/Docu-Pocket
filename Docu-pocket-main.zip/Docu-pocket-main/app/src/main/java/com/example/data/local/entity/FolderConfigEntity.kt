package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "folder_config")
data class FolderConfigEntity(
    @PrimaryKey
    val folderPath: String,
    val autoDeleteEnabled: Boolean = false,
    val durationHours: Long = 24L,
    val createdAt: Long = System.currentTimeMillis(),
    val expiresAt: Long = 0L
)
