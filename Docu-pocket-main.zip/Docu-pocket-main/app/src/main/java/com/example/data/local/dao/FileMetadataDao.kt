package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.local.entity.FileMetadataEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface FileMetadataDao {
    @Query("SELECT * FROM file_metadata")
    fun getAllMetadataFlow(): Flow<List<FileMetadataEntity>>

    @Query("SELECT * FROM file_metadata WHERE relativePath = :path LIMIT 1")
    suspend fun getMetadata(path: String): FileMetadataEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(metadata: FileMetadataEntity)

    @Query("DELETE FROM file_metadata WHERE relativePath = :path")
    suspend fun delete(path: String)

    @Query("DELETE FROM file_metadata WHERE relativePath LIKE :folderPrefix || '%'")
    suspend fun deleteUnderFolder(folderPrefix: String)

    @Query("UPDATE file_metadata SET relativePath = :newPath WHERE relativePath = :oldPath")
    suspend fun rename(oldPath: String, newPath: String)
}
