package com.example.data.model

import com.example.data.local.entity.FolderConfigEntity
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class VaultItem(
    val name: String,
    val relativePath: String,
    val file: File,
    val isDirectory: Boolean,
    val sizeBytes: Long,
    val lastModified: Long,
    val category: FileCategory,
    val description: String? = null,
    val autoDeleteConfig: FolderConfigEntity? = null,
    val childCount: Int = 0
) {
    val hasDescription: Boolean
        get() = !description.isNullOrBlank()

    val formattedSize: String
        get() {
            if (isDirectory) {
                return "$childCount ${if (childCount == 1) "item" else "items"}"
            }
            if (sizeBytes <= 0) return "0 B"
            val units = arrayOf("B", "KB", "MB", "GB", "TB")
            val digitGroups = (Math.log10(sizeBytes.toDouble()) / Math.log10(1024.0)).toInt().coerceIn(0, units.size - 1)
            val value = sizeBytes / Math.pow(1024.0, digitGroups.toDouble())
            return String.format(Locale.getDefault(), "%.1f %s", value, units[digitGroups])
        }

    val formattedDate: String
        get() {
            val sdf = SimpleDateFormat("MMM d, yyyy • HH:mm", Locale.getDefault())
            return sdf.format(Date(lastModified))
        }

    val autoDeleteStatus: String?
        get() {
            if (!isDirectory || autoDeleteConfig == null || !autoDeleteConfig.autoDeleteEnabled) {
                return null
            }
            val remainingMs = autoDeleteConfig.expiresAt - System.currentTimeMillis()
            if (remainingMs <= 0) {
                return "Expired (Cleaning)"
            }
            val hours = remainingMs / (1000 * 60 * 60)
            val days = hours / 24
            return if (days > 0) {
                "Deletes in ${days}d ${hours % 24}h"
            } else if (hours > 0) {
                "Deletes in ${hours}h"
            } else {
                val mins = (remainingMs / (1000 * 60)).coerceAtLeast(1)
                "Deletes in ${mins}m"
            }
        }
}
