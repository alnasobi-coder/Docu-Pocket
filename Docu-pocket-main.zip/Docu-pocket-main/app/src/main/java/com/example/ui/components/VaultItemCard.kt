package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DriveFileMove
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.model.FileCategory
import com.example.data.model.VaultItem
import com.example.ui.theme.DescriptionDotColor

@Composable
fun VaultItemListRow(
    item: VaultItem,
    onClick: () -> Unit,
    onMenuAction: (VaultMenuAction) -> Unit,
    modifier: Modifier = Modifier
) {
    var menuExpanded by remember { mutableStateOf(false) }

    Card(
        onClick = onClick,
        modifier = modifier
            .fillMaxWidth()
            .testTag("vault_item_${item.name}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Thumbnail / Icon with Description Badge Dot
            ItemThumbnailBox(
                item = item,
                modifier = Modifier.size(48.dp)
            )

            Spacer(modifier = Modifier.width(12.dp))

            // File Info
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = item.name,
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.weight(1f, fill = false)
                    )

                    // Small indicator pill if file has description
                    if (item.hasDescription) {
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = DescriptionDotColor.copy(alpha = 0.15f),
                            contentColor = DescriptionDotColor
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(DescriptionDotColor)
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(
                                    text = "Note",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(2.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = item.formattedSize,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "•",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                    )
                    Text(
                        text = item.formattedDate,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1
                    )
                }

                // Auto-delete badge for folders
                if (item.autoDeleteStatus != null) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.8f),
                        contentColor = MaterialTheme.colorScheme.onErrorContainer
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Schedule,
                                contentDescription = "Auto delete timer",
                                modifier = Modifier.size(11.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = item.autoDeleteStatus ?: "",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }

            // More Options Menu
            Box {
                IconButton(
                    onClick = { menuExpanded = true },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.MoreVert,
                        contentDescription = "Options for ${item.name}",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                ItemDropdownMenu(
                    expanded = menuExpanded,
                    onDismiss = { menuExpanded = false },
                    item = item,
                    onAction = { action ->
                        menuExpanded = false
                        onMenuAction(action)
                    }
                )
            }
        }
    }
}

@Composable
fun VaultItemGridCard(
    item: VaultItem,
    onClick: () -> Unit,
    onMenuAction: (VaultMenuAction) -> Unit,
    modifier: Modifier = Modifier
) {
    var menuExpanded by remember { mutableStateOf(false) }

    Card(
        onClick = onClick,
        modifier = modifier
            .fillMaxWidth()
            .testTag("vault_item_grid_${item.name}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth()
        ) {
            // Thumbnail / Icon Header with Dot Badge
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1.2f)
                    .background(item.category.color.copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
            ) {
                if (!item.isDirectory && item.category == FileCategory.IMAGE) {
                    AsyncImage(
                        model = ImageRequest.Builder(LocalContext.current)
                            .data(item.file)
                            .crossfade(true)
                            .build(),
                        contentDescription = item.name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Icon(
                        imageVector = item.category.icon,
                        contentDescription = item.category.title,
                        tint = item.category.color,
                        modifier = Modifier.size(42.dp)
                    )
                }

                // Description Dot Indicator on Thumbnail Corner
                if (item.hasDescription) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(8.dp)
                            .size(12.dp)
                            .clip(CircleShape)
                            .background(DescriptionDotColor)
                            .border(1.5.dp, Color.White, CircleShape)
                    )
                }

                // Auto-delete indicator overlay on grid
                if (item.autoDeleteStatus != null) {
                    Surface(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(4.dp),
                        shape = RoundedCornerShape(4.dp),
                        color = Color.Black.copy(alpha = 0.65f),
                        contentColor = Color.White
                    ) {
                        Text(
                            text = item.autoDeleteStatus ?: "",
                            fontSize = 9.sp,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            // Bottom Name and Menu
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = item.name,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = item.formattedSize,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Box {
                    IconButton(
                        onClick = { menuExpanded = true },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.MoreVert,
                            contentDescription = "Menu",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    ItemDropdownMenu(
                        expanded = menuExpanded,
                        onDismiss = { menuExpanded = false },
                        item = item,
                        onAction = { action ->
                            menuExpanded = false
                            onMenuAction(action)
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun ItemThumbnailBox(
    item: VaultItem,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            shape = RoundedCornerShape(10.dp),
            color = item.category.color.copy(alpha = 0.14f)
        ) {
            if (!item.isDirectory && item.category == FileCategory.IMAGE) {
                AsyncImage(
                    model = ImageRequest.Builder(LocalContext.current)
                        .data(item.file)
                        .crossfade(true)
                        .build(),
                    contentDescription = item.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(RoundedCornerShape(10.dp))
                )
            } else {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = item.category.icon,
                        contentDescription = item.category.title,
                        tint = item.category.color,
                        modifier = Modifier.size(26.dp)
                    )
                }
            }
        }

        // Prominent Description Badge Dot
        if (item.hasDescription) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .offset(x = 3.dp, y = (-3).dp)
                    .size(11.dp)
                    .clip(CircleShape)
                    .background(DescriptionDotColor)
                    .border(2.dp, MaterialTheme.colorScheme.surface, CircleShape)
            )
        }
    }
}

@Composable
fun ItemDropdownMenu(
    expanded: Boolean,
    onDismiss: () -> Unit,
    item: VaultItem,
    onAction: (VaultMenuAction) -> Unit
) {
    DropdownMenu(
        expanded = expanded,
        onDismissRequest = onDismiss
    ) {
        DropdownMenuItem(
            text = { Text(if (item.isDirectory) "Open Folder" else "View / Preview") },
            onClick = { onAction(VaultMenuAction.Open(item)) },
            leadingIcon = { Icon(Icons.Default.Visibility, contentDescription = null) }
        )

        DropdownMenuItem(
            text = {
                Text(
                    if (item.hasDescription) "Edit Description" else "Add Description"
                )
            },
            onClick = { onAction(VaultMenuAction.EditDescription(item)) },
            leadingIcon = {
                Icon(
                    Icons.Default.EditNote,
                    contentDescription = null,
                    tint = if (item.hasDescription) DescriptionDotColor else MaterialTheme.colorScheme.primary
                )
            }
        )

        if (!item.isDirectory && item.category == FileCategory.CODE_TEXT) {
            DropdownMenuItem(
                text = { Text("Edit Text Content") },
                onClick = { onAction(VaultMenuAction.EditTextContent(item)) },
                leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null) }
            )
        }

        if (item.isDirectory) {
            DropdownMenuItem(
                text = { Text("Auto-Delete Settings") },
                onClick = { onAction(VaultMenuAction.ConfigureAutoDelete(item)) },
                leadingIcon = { Icon(Icons.Default.Schedule, contentDescription = null) }
            )
        }

        DropdownMenuItem(
            text = { Text("Rename") },
            onClick = { onAction(VaultMenuAction.Rename(item)) },
            leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null) }
        )

        DropdownMenuItem(
            text = { Text("Move to Folder") },
            onClick = { onAction(VaultMenuAction.Move(item)) },
            leadingIcon = { Icon(Icons.Default.DriveFileMove, contentDescription = null) }
        )

        if (!item.isDirectory) {
            DropdownMenuItem(
                text = { Text("Share File") },
                onClick = { onAction(VaultMenuAction.Share(item)) },
                leadingIcon = { Icon(Icons.Default.Share, contentDescription = null) }
            )
        }

        HorizontalDivider()

        DropdownMenuItem(
            text = {
                Text(
                    "Delete",
                    color = MaterialTheme.colorScheme.error
                )
            },
            onClick = { onAction(VaultMenuAction.Delete(item)) },
            leadingIcon = {
                Icon(
                    Icons.Default.Delete,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.error
                )
            }
        )
    }
}

sealed class VaultMenuAction {
    data class Open(val item: VaultItem) : VaultMenuAction()
    data class EditDescription(val item: VaultItem) : VaultMenuAction()
    data class EditTextContent(val item: VaultItem) : VaultMenuAction()
    data class ConfigureAutoDelete(val item: VaultItem) : VaultMenuAction()
    data class Rename(val item: VaultItem) : VaultMenuAction()
    data class Move(val item: VaultItem) : VaultMenuAction()
    data class Share(val item: VaultItem) : VaultMenuAction()
    data class Delete(val item: VaultItem) : VaultMenuAction()
}
