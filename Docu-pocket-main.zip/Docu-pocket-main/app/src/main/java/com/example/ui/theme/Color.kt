package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Colors
val LightPrimary = Color(0xFF1D4ED8)
val LightOnPrimary = Color(0xFFFFFFFF)
val LightPrimaryContainer = Color(0xFFDBEAFE)
val LightOnPrimaryContainer = Color(0xFF1E3A8A)

val LightSecondary = Color(0xFF0F766E)
val LightOnSecondary = Color(0xFFFFFFFF)
val LightSecondaryContainer = Color(0xFFCCFBF1)
val LightOnSecondaryContainer = Color(0xFF134E4A)

val LightTertiary = Color(0xFF7C3AED)
val LightOnTertiary = Color(0xFFFFFFFF)
val LightTertiaryContainer = Color(0xFFEDE9FE)
val LightOnTertiaryContainer = Color(0xFF4C1D95)

val LightBackground = Color(0xFFF8FAFC)
val LightOnBackground = Color(0xFF0F172A)
val LightSurface = Color(0xFFFFFFFF)
val LightOnSurface = Color(0xFF0F172A)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightOnSurfaceVariant = Color(0xFF475569)
val LightOutline = Color(0xFFCBD5E1)

// Dark Colors
val DarkPrimary = Color(0xFF60A5FA)
val DarkOnPrimary = Color(0xFF1E3A8A)
val DarkPrimaryContainer = Color(0xFF1E40AF)
val DarkOnPrimaryContainer = Color(0xFFDBEAFE)

val DarkSecondary = Color(0xFF2DD4BF)
val DarkOnSecondary = Color(0xFF134E4A)
val DarkSecondaryContainer = Color(0xFF115E59)
val DarkOnSecondaryContainer = Color(0xFFCCFBF1)

val DarkTertiary = Color(0xFFA78BFA)
val DarkOnTertiary = Color(0xFF4C1D95)
val DarkTertiaryContainer = Color(0xFF5B21B6)
val DarkOnTertiaryContainer = Color(0xFFEDE9FE)

val DarkBackground = Color(0xFF0B0F17)
val DarkOnBackground = Color(0xFFF1F5F9)
val DarkSurface = Color(0xFF111827)
val DarkOnSurface = Color(0xFFF1F5F9)
val DarkSurfaceVariant = Color(0xFF1E293B)
val DarkOnSurfaceVariant = Color(0xFF94A3B8)
val DarkOutline = Color(0xFF334155)

// Category Accent Colors
val AccentImage = Color(0xFF8B5CF6)
val AccentPdf = Color(0xFFEF4444)
val AccentDoc = Color(0xFF3B82F6)
val AccentAudio = Color(0xFF10B981)
val AccentVideo = Color(0xFFF97316)
val AccentArchive = Color(0xFFEAB308)
val AccentCode = Color(0xFF06B6D4)
val AccentFolder = Color(0xFFF59E0B)

// Indicator Dot Colors
val DescriptionDotColor = Color(0xFFF43F5E) // Bright vibrant Rose / Coral dot for clear visibility
