package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "file_metadata")
data class FileMetadataEntity(
    @PrimaryKey
    val relativePath: String,
    val description: String = "",
    val updatedAt: Long = System.currentTimeMillis()
)
