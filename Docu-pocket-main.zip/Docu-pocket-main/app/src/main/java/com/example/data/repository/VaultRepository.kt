package com.example.data.repository

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Environment
import android.os.StatFs
import android.provider.OpenableColumns
import android.media.ExifInterface
import com.example.data.local.VaultDatabase
import com.example.data.local.entity.FileMetadataEntity
import com.example.data.local.entity.FolderConfigEntity
import com.example.data.model.CategoryUsage
import com.example.data.model.FileCategory
import com.example.data.model.StorageAnalytics
import com.example.data.model.VaultItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream

class VaultRepository(private val context: Context) {

    private val database = VaultDatabase.getInstance(context)
    private val fileMetadataDao = database.fileMetadataDao()
    private val folderConfigDao = database.folderConfigDao()

    // Independent hidden directory starting with '.'
    val vaultRoot: File by lazy {
        val root = File(context.filesDir, ".vault")
        if (!root.exists()) {
            root.mkdirs()
        }
        root
    }

    init {
        // Ensure root exists
        if (!vaultRoot.exists()) {
            vaultRoot.mkdirs()
        }
    }

    fun observeAllMetadata(): Flow<List<FileMetadataEntity>> = fileMetadataDao.getAllMetadataFlow()

    fun observeAllFolderConfigs(): Flow<List<FolderConfigEntity>> = folderConfigDao.getAllFolderConfigsFlow()

    /**
     * Resolves a sanitized relative path inside the hidden vault.
     */
    fun resolveFile(relativePath: String): File {
        val cleanPath = relativePath.trim().trimStart('/').replace("..", "")
        return if (cleanPath.isEmpty()) vaultRoot else File(vaultRoot, cleanPath)
    }

    fun getRelativePath(file: File): String {
        return file.relativeTo(vaultRoot).path.replace('\\', '/')
    }

    /**
     * Lists items inside the relative path folder.
     */
    suspend fun listItems(
        relativeFolder: String,
        metadataList: List<FileMetadataEntity>,
        folderConfigs: List<FolderConfigEntity>
    ): List<VaultItem> = withContext(Dispatchers.IO) {
        val targetDir = resolveFile(relativeFolder)
        if (!targetDir.exists() || !targetDir.isDirectory) {
            return@withContext emptyList()
        }

        val metaMap = metadataList.associateBy { it.relativePath }
        val configMap = folderConfigs.associateBy { it.folderPath }

        val files = targetDir.listFiles() ?: return@withContext emptyList()

        files.map { file ->
            val relPath = getRelativePath(file)
            val isDir = file.isDirectory
            val size = if (isDir) computeDirectorySize(file) else file.length()
            val childCount = if (isDir) file.listFiles()?.size ?: 0 else 0
            val meta = metaMap[relPath]
            val config = if (isDir) configMap[relPath] else null

            VaultItem(
                name = file.name,
                relativePath = relPath,
                file = file,
                isDirectory = isDir,
                sizeBytes = size,
                lastModified = file.lastModified(),
                category = FileCategory.fromFile(file.name, isDir),
                description = meta?.description,
                autoDeleteConfig = config,
                childCount = childCount
            )
        }
    }

    /**
     * Recursively list all files across the entire vault (for global search).
     */
    suspend fun listAllFilesRecursively(
        metadataList: List<FileMetadataEntity>,
        folderConfigs: List<FolderConfigEntity>
    ): List<VaultItem> = withContext(Dispatchers.IO) {
        val metaMap = metadataList.associateBy { it.relativePath }
        val configMap = folderConfigs.associateBy { it.folderPath }

        val result = mutableListOf<VaultItem>()
        fun scanDir(dir: File) {
            val children = dir.listFiles() ?: return
            for (child in children) {
                val relPath = getRelativePath(child)
                val isDir = child.isDirectory
                val size = if (isDir) computeDirectorySize(child) else child.length()
                val childCount = if (isDir) child.listFiles()?.size ?: 0 else 0
                val meta = metaMap[relPath]
                val config = if (isDir) configMap[relPath] else null

                result.add(
                    VaultItem(
                        name = child.name,
                        relativePath = relPath,
                        file = child,
                        isDirectory = isDir,
                        sizeBytes = size,
                        lastModified = child.lastModified(),
                        category = FileCategory.fromFile(child.name, isDir),
                        description = meta?.description,
                        autoDeleteConfig = config,
                        childCount = childCount
                    )
                )
                if (isDir) {
                    scanDir(child)
                }
            }
        }
        scanDir(vaultRoot)
        result
    }

    /**
     * Creates a new folder with optional auto-delete configuration.
     */
    suspend fun createFolder(
        parentRelativePath: String,
        folderName: String,
        autoDeleteEnabled: Boolean,
        durationHours: Long
    ): Boolean = withContext(Dispatchers.IO) {
        val parent = resolveFile(parentRelativePath)
        val newFolder = File(parent, folderName.trim())
        if (newFolder.exists()) return@withContext false
        val created = newFolder.mkdirs()
        if (created) {
            val relPath = getRelativePath(newFolder)
            val expiresAt = if (autoDeleteEnabled) {
                System.currentTimeMillis() + (durationHours * 3600 * 1000)
            } else {
                0L
            }
            folderConfigDao.insertOrUpdate(
                FolderConfigEntity(
                    folderPath = relPath,
                    autoDeleteEnabled = autoDeleteEnabled,
                    durationHours = durationHours,
                    createdAt = System.currentTimeMillis(),
                    expiresAt = expiresAt
                )
            )
        }
        created
    }

    /**
     * Updates auto-delete configuration for an existing folder.
     */
    suspend fun updateFolderAutoDelete(
        folderRelativePath: String,
        enabled: Boolean,
        durationHours: Long
    ) = withContext(Dispatchers.IO) {
        val existing = folderConfigDao.getConfig(folderRelativePath)
        val createdAt = existing?.createdAt ?: System.currentTimeMillis()
        val expiresAt = if (enabled) {
            System.currentTimeMillis() + (durationHours * 3600 * 1000)
        } else {
            0L
        }
        folderConfigDao.insertOrUpdate(
            FolderConfigEntity(
                folderPath = folderRelativePath,
                autoDeleteEnabled = enabled,
                durationHours = durationHours,
                createdAt = createdAt,
                expiresAt = expiresAt
            )
        )
    }

    /**
     * Imports a file from an Android content URI (from file picker or share sheet).
     */
    suspend fun importFileFromUri(
        uri: Uri,
        targetFolderRelative: String,
        customName: String? = null,
        description: String? = null
    ): File? = withContext(Dispatchers.IO) {
        val targetDir = resolveFile(targetFolderRelative)
        if (!targetDir.exists()) targetDir.mkdirs()

        val fileName = customName?.takeIf { it.isNotBlank() } ?: queryDisplayName(uri) ?: "imported_${System.currentTimeMillis()}"
        val sanitizedName = sanitizeFilename(fileName)
        var destFile = File(targetDir, sanitizedName)

        // Handle duplicates
        var counter = 1
        val base = sanitizedName.substringBeforeLast('.')
        val ext = if (sanitizedName.contains('.')) "." + sanitizedName.substringAfterLast('.') else ""
        while (destFile.exists()) {
            destFile = File(targetDir, "${base}_$counter$ext")
            counter++
        }

        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(destFile).use { output ->
                input.copyTo(output)
            }
        } ?: return@withContext null

        val relPath = getRelativePath(destFile)
        if (!description.isNullOrBlank()) {
            fileMetadataDao.insertOrUpdate(
                FileMetadataEntity(
                    relativePath = relPath,
                    description = description.trim(),
                    updatedAt = System.currentTimeMillis()
                )
            )
        }

        destFile
    }

    /**
     * Saves or clears the description for a file.
     */
    suspend fun saveDescription(relativePath: String, description: String) = withContext(Dispatchers.IO) {
        val trimmed = description.trim()
        if (trimmed.isEmpty()) {
            fileMetadataDao.delete(relativePath)
        } else {
            fileMetadataDao.insertOrUpdate(
                FileMetadataEntity(
                    relativePath = relativePath,
                    description = trimmed,
                    updatedAt = System.currentTimeMillis()
                )
            )
        }
    }

    /**
     * Renames a file or folder and updates Room metadata.
     */
    suspend fun renameItem(relativePath: String, newName: String): Boolean = withContext(Dispatchers.IO) {
        val file = resolveFile(relativePath)
        if (!file.exists()) return@withContext false
        val sanitized = sanitizeFilename(newName.trim())
        if (sanitized.isEmpty()) return@withContext false
        val dest = File(file.parentFile, sanitized)
        if (dest.exists()) return@withContext false

        val success = file.renameTo(dest)
        if (success) {
            val newRelPath = getRelativePath(dest)
            fileMetadataDao.rename(relativePath, newRelPath)
            folderConfigDao.rename(relativePath, newRelPath)
        }
        success
    }

    /**
     * Deletes a file or directory recursively and removes DB records.
     */
    suspend fun deleteItem(relativePath: String): Boolean = withContext(Dispatchers.IO) {
        val file = resolveFile(relativePath)
        if (!file.exists()) return@withContext false
        val deleted = if (file.isDirectory) file.deleteRecursively() else file.delete()
        if (deleted) {
            fileMetadataDao.delete(relativePath)
            fileMetadataDao.deleteUnderFolder(relativePath)
            folderConfigDao.delete(relativePath)
            folderConfigDao.deleteUnderFolder(relativePath)
        }
        deleted
    }

    /**
     * Moves a file or folder into a destination folder.
     */
    suspend fun moveItem(sourceRelativePath: String, destFolderRelativePath: String): Boolean = withContext(Dispatchers.IO) {
        val sourceFile = resolveFile(sourceRelativePath)
        val destFolder = resolveFile(destFolderRelativePath)
        if (!sourceFile.exists() || !destFolder.exists() || !destFolder.isDirectory) return@withContext false
        val destFile = File(destFolder, sourceFile.name)
        if (destFile.exists()) return@withContext false

        val moved = sourceFile.renameTo(destFile)
        if (moved) {
            val newRelPath = getRelativePath(destFile)
            fileMetadataDao.rename(sourceRelativePath, newRelPath)
            folderConfigDao.rename(sourceRelativePath, newRelPath)
        }
        moved
    }

    /**
     * Reads text content of a file.
     */
    suspend fun readTextFile(relativePath: String): String = withContext(Dispatchers.IO) {
        val file = resolveFile(relativePath)
        if (file.exists() && file.isFile) {
            file.readText()
        } else {
            ""
        }
    }

    /**
     * Writes text content to a file (create or edit).
     */
    suspend fun writeTextFile(parentRelativeFolder: String, fileName: String, content: String): File = withContext(Dispatchers.IO) {
        val folder = resolveFile(parentRelativeFolder)
        if (!folder.exists()) folder.mkdirs()
        val sanitized = sanitizeFilename(fileName)
        val target = File(folder, sanitized)
        target.writeText(content)
        target
    }

    /**
     * Checks and executes auto-deletion for expired folders.
     */
    suspend fun checkAndExecuteAutoDelete(): Int = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val activeConfigs = folderConfigDao.getActiveAutoDeleteFolders()
        var deletedCount = 0

        for (config in activeConfigs) {
            if (config.expiresAt in 1..now) {
                val folder = resolveFile(config.folderPath)
                if (folder.exists() && folder.isDirectory) {
                    folder.deleteRecursively()
                    deletedCount++
                }
                folderConfigDao.delete(config.folderPath)
                folderConfigDao.deleteUnderFolder(config.folderPath)
                fileMetadataDao.deleteUnderFolder(config.folderPath)
            }
        }
        deletedCount
    }

    /**
     * Converts a list of image Uris or image File paths into a multi-page PDF document,
     * saving it into the destination vault folder.
     */
    suspend fun convertImagesToPdf(
        imageUris: List<Uri>,
        outputName: String,
        targetFolderRelative: String,
        description: String? = null
    ): File = withContext(Dispatchers.IO) {
        val targetDir = resolveFile(targetFolderRelative)
        if (!targetDir.exists()) targetDir.mkdirs()

        val sanitizedPdfName = sanitizeFilename(if (outputName.endsWith(".pdf", true)) outputName else "$outputName.pdf")
        var destFile = File(targetDir, sanitizedPdfName)
        var counter = 1
        val base = sanitizedPdfName.removeSuffix(".pdf")
        while (destFile.exists()) {
            destFile = File(targetDir, "${base}_$counter.pdf")
            counter++
        }

        val pdfDoc = PdfDocument()
        val standardWidth = 595 // Standard A4 width in points
        val standardHeight = 842 // Standard A4 height in points

        imageUris.forEachIndexed { index, uri ->
            val bitmap = decodeBitmapFromUri(uri, standardWidth * 2, standardHeight * 2)
            if (bitmap != null) {
                // Determine page dimensions based on bitmap orientation
                val isLandscape = bitmap.width > bitmap.height
                val pageWidth = if (isLandscape) standardHeight else standardWidth
                val pageHeight = if (isLandscape) standardWidth else standardHeight

                val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, index + 1).create()
                val page = pdfDoc.startPage(pageInfo)
                val canvas = page.canvas

                // Scale bitmap to fit page with margins
                val margin = 20f
                val availW = pageWidth - (margin * 2)
                val availH = pageHeight - (margin * 2)

                val scale = minOf(availW / bitmap.width, availH / bitmap.height)
                val drawW = bitmap.width * scale
                val drawH = bitmap.height * scale
                val left = margin + (availW - drawW) / 2f
                val top = margin + (availH - drawH) / 2f

                val paint = Paint(Paint.FILTER_BITMAP_FLAG)
                val matrix = Matrix().apply {
                    postScale(scale, scale)
                    postTranslate(left, top)
                }
                canvas.drawBitmap(bitmap, matrix, paint)
                pdfDoc.finishPage(page)
                bitmap.recycle()
            }
        }

        FileOutputStream(destFile).use { out ->
            pdfDoc.writeTo(out)
        }
        pdfDoc.close()

        val relPath = getRelativePath(destFile)
        if (!description.isNullOrBlank()) {
            fileMetadataDao.insertOrUpdate(
                FileMetadataEntity(
                    relativePath = relPath,
                    description = description.trim(),
                    updatedAt = System.currentTimeMillis()
                )
            )
        }

        destFile
    }

    /**
     * Computes storage analytics: device space and vault category breakdown.
     */
    suspend fun getStorageAnalytics(): StorageAnalytics = withContext(Dispatchers.IO) {
        // Device storage stats
        var totalDevice = 0L
        var freeDevice = 0L
        try {
            val stat = StatFs(Environment.getDataDirectory().path)
            totalDevice = stat.totalBytes
            freeDevice = stat.availableBytes
        } catch (_: Exception) {}

        val usedDevice = (totalDevice - freeDevice).coerceAtLeast(0L)

        // Vault breakdown
        val categorySizes = mutableMapOf<FileCategory, Long>()
        val categoryCounts = mutableMapOf<FileCategory, Int>()
        var vaultTotalBytes = 0L
        var vaultTotalFiles = 0
        var vaultTotalFolders = 0

        fun scan(dir: File) {
            val list = dir.listFiles() ?: return
            for (f in list) {
                if (f.isDirectory) {
                    vaultTotalFolders++
                    scan(f)
                } else {
                    vaultTotalFiles++
                    val len = f.length()
                    vaultTotalBytes += len
                    val cat = FileCategory.fromFile(f.name, false)
                    categorySizes[cat] = (categorySizes[cat] ?: 0L) + len
                    categoryCounts[cat] = (categoryCounts[cat] ?: 0) + 1
                }
            }
        }
        scan(vaultRoot)

        val breakdown = FileCategory.entries
            .filter { it != FileCategory.FOLDER }
            .map { cat ->
                val bytes = categorySizes[cat] ?: 0L
                val count = categoryCounts[cat] ?: 0
                val pct = if (vaultTotalBytes > 0) (bytes.toFloat() / vaultTotalBytes.toFloat()) * 100f else 0f
                CategoryUsage(
                    category = cat,
                    totalBytes = bytes,
                    fileCount = count,
                    percentageOfVault = pct
                )
            }
            .sortedByDescending { it.totalBytes }

        val activeAutoDeletes = folderConfigDao.getActiveAutoDeleteFolders().size

        StorageAnalytics(
            totalDeviceBytes = totalDevice,
            freeDeviceBytes = freeDevice,
            usedDeviceBytes = usedDevice,
            totalVaultBytes = vaultTotalBytes,
            totalVaultFiles = vaultTotalFiles,
            totalVaultFolders = vaultTotalFolders,
            categoryBreakdown = breakdown,
            activeAutoDeleteFoldersCount = activeAutoDeletes
        )
    }

    /**
     * Helper to compute directory size.
     */
    private fun computeDirectorySize(dir: File): Long {
        var size = 0L
        val files = dir.listFiles() ?: return 0L
        for (f in files) {
            size += if (f.isDirectory) computeDirectorySize(f) else f.length()
        }
        return size
    }

    /**
     * Resolves display name from Uri.
     */
    private fun queryDisplayName(uri: Uri): String? {
        if (uri.scheme == "file") return uri.lastPathSegment
        return try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (nameIndex != -1) cursor.getString(nameIndex) else null
                } else null
            } ?: uri.lastPathSegment
        } catch (_: Exception) {
            uri.lastPathSegment
        }
    }

    private fun sanitizeFilename(name: String): String {
        return name.replace(Regex("[/\\\\:*?\"<>|]"), "_").trim()
    }

    private fun decodeBitmapFromUri(uri: Uri, reqWidth: Int, reqHeight: Int): Bitmap? {
        return try {
            val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            context.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, options)
            }

            options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight)
            options.inJustDecodeBounds = false

            var bitmap = context.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, options)
            }

            // Correct orientation from EXIF if needed
            context.contentResolver.openInputStream(uri)?.use { stream ->
                val exif = ExifInterface(stream)
                val orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
                if (bitmap != null) {
                    bitmap = rotateBitmapIfRequired(bitmap!!, orientation)
                }
            }

            bitmap
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun calculateInSampleSize(options: BitmapFactory.Options, reqWidth: Int, reqHeight: Int): Int {
        val (height: Int, width: Int) = options.run { outHeight to outWidth }
        var inSampleSize = 1
        if (height > reqHeight || width > reqWidth) {
            val halfHeight: Int = height / 2
            val halfWidth: Int = width / 2
            while (halfHeight / inSampleSize >= reqHeight && halfWidth / inSampleSize >= reqWidth) {
                inSampleSize *= 2
            }
        }
        return inSampleSize
    }

    private fun rotateBitmapIfRequired(bitmap: Bitmap, orientation: Int): Bitmap {
        val matrix = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
            else -> return bitmap
        }
        val rotated = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
        if (rotated != bitmap) {
            bitmap.recycle()
        }
        return rotated
    }
}
