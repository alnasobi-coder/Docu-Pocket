package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.local.entity.FolderConfigEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface FolderConfigDao {
    @Query("SELECT * FROM folder_config")
    fun getAllFolderConfigsFlow(): Flow<List<FolderConfigEntity>>

    @Query("SELECT * FROM folder_config WHERE folderPath = :path LIMIT 1")
    suspend fun getConfig(path: String): FolderConfigEntity?

    @Query("SELECT * FROM folder_config WHERE autoDeleteEnabled = 1")
    suspend fun getActiveAutoDeleteFolders(): List<FolderConfigEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(config: FolderConfigEntity)

    @Query("DELETE FROM folder_config WHERE folderPath = :path")
    suspend fun delete(path: String)

    @Query("DELETE FROM folder_config WHERE folderPath LIKE :folderPrefix || '%'")
    suspend fun deleteUnderFolder(folderPrefix: String)

    @Query("UPDATE folder_config SET folderPath = :newPath WHERE folderPath = :oldPath")
    suspend fun rename(oldPath: String, newPath: String)
}
