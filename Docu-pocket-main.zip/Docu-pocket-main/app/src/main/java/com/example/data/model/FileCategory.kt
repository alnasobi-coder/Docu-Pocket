package com.example.data.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

enum class FileCategory(
    val title: String,
    val mimeTypes: Array<String>,
    val icon: ImageVector,
    val color: Color
) {
    FOLDER("Folders", emptyArray(), Icons.Default.Folder, Color(0xFFF59E0B)),
    IMAGE("Images", arrayOf("image/*"), Icons.Default.Image, Color(0xFF8B5CF6)),
    PDF("PDF Documents", arrayOf("application/pdf"), Icons.Default.PictureAsPdf, Color(0xFFEF4444)),
    DOCUMENT("Documents", arrayOf("application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/vnd.ms-excel", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "application/vnd.ms-powerpoint", "application/vnd.openxmlformats-officedocument.presentationml.presentation", "application/rtf", "application/epub+zip"), Icons.Default.Description, Color(0xFF3B82F6)),
    AUDIO("Audio", arrayOf("audio/*"), Icons.Default.AudioFile, Color(0xFF10B981)),
    VIDEO("Videos", arrayOf("video/*"), Icons.Default.VideoFile, Color(0xFFF97316)),
    ARCHIVE("Archives", arrayOf("application/zip", "application/x-rar-compressed", "application/x-7z-compressed", "application/x-tar", "application/gzip"), Icons.Default.Archive, Color(0xFFEAB308)),
    CODE_TEXT("Code & Text", arrayOf("text/*", "application/json", "application/xml", "application/javascript"), Icons.Default.Code, Color(0xFF06B6D4)),
    OTHER("Other Files", arrayOf("*/*"), Icons.Default.InsertDriveFile, Color(0xFF64748B));

    companion object {
        fun fromFile(name: String, isDir: Boolean): FileCategory {
            if (isDir) return FOLDER
            val ext = name.substringAfterLast('.', "").lowercase()
            return when (ext) {
                "jpg", "jpeg", "png", "webp", "gif", "bmp", "svg", "heic" -> IMAGE
                "pdf" -> PDF
                "doc", "docx", "xls", "xlsx", "ppt", "pptx", "rtf", "odt", "ods", "odp", "epub" -> DOCUMENT
                "mp3", "wav", "m4a", "ogg", "flac", "aac", "opus", "wma" -> AUDIO
                "mp4", "mkv", "mov", "avi", "webm", "flv", "wmv", "3gp" -> VIDEO
                "zip", "rar", "7z", "tar", "gz", "bz2" -> ARCHIVE
                "txt", "md", "json", "xml", "html", "css", "js", "ts", "kt", "java", "py", "c", "cpp", "cs", "sql", "sh", "yaml", "yml", "csv", "log" -> CODE_TEXT
                else -> OTHER
            }
        }
    }
}
